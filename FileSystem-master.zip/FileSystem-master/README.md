FileSystem [Archived]
=====================

**This GitHub project has been archived.** Ongoing development on this project can be found in <https://github.com/aspnet/Extensions>.

File Provider abstractions. Contains file system abstractions and file system globbing.

This project is part of ASP.NET Core. You can find samples, documentation and getting started instructions for ASP.NET Core at the [AspNetCore](https://github.com/aspnet/AspNetCore) repo.
