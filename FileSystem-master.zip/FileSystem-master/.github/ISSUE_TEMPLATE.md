THIS ISSUE TRACKER IS CLOSED - please log new issues here: https://github.com/aspnet/Home/issues

For information about this change, see https://github.com/aspnet/Announcements/issues/283
